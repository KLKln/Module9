"""
Program: set_ops.py
Author: Kelly Klein
Last date modified: 7/1/2020
This program will accept and print a set, one item at a time
"""


def print_set(new_set = {1,3,5,7,9,11,13}):

    for i in new_set:
        print(i)
        

if __name__ == '__main__':
    print_set()
