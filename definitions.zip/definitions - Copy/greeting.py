"""
Program: greeting.py
Author: Kelly Klein
Last date modified: 7/1/2020
This program will run two functions, greeting and code_author
in my_definitions_test
"""


def greeting():
    print('Hello, Friend!')


def code_author():
    print('Kelly Klein wrote this code!')


if __name__ == '__main__':
    greeting()
    code_author()
